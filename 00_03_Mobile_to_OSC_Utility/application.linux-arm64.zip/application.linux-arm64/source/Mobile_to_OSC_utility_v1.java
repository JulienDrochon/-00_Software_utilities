import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.net.InetAddress; 
import websockets.*; 
import processing.net.*; 
import java.net.Inet4Address; 
import com.cage.zxing4p3.*; 
import netP5.*; 
import oscP5.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Mobile_to_OSC_utility_v1 extends PApplet {

//  see forum question 
//  https://discourse.processing.org/t/how-can-i-send-a-file-with-server-write/4360






Server myServer;

WebsocketServer ws;
int now;

InetAddress inet;
String myIP;


ZXING4P zxing4p;
PImage  QRCode;

int port = 5204;
PrintWriter test;
String[] lines;
int ccount=0;
String inString="";
String[] req;
String[] incheck;

boolean generated;
boolean verbose = false;

float[] mobileVals;




ControlP5 cp5, controlMapValues;
Textfield oscSettingAddress, oscSettingPort;
Bang oscBang;
OscP5 oscP5;
NetAddress myRemoteLocation;
OscBundle myBundle;
OscMessage myMessage;
String oscString="";
DropdownList d1;

Textfield[] minInputValControl, maxInputValControl, minOutputValControl, maxOutputValControl, oscMessage;
Bang[] minInputValSet, maxInputValSet;

String[] settingsLoaded;

int wsPort = 5205;
//__________________________________________________________________
public void setup() {

  


  // IP server

  try {
    inet = Inet4Address.getLocalHost();

    myIP = inet.getHostAddress();
    //adresseWebsocket = myIP;
  }
  catch (Exception e) {
    e.printStackTrace();
    myIP = "couldnt get IP";
  }



  //HTML
  // println("(click on canvas window and use) keyboard [v][V] to toggle diagnostic");
  myServer = new Server(this, port);
  make_HTML_file();
  load_HTML_file();
  //println("from any browser use: " + Server.ip() + ":"+port);

  // QR code
  zxing4p = new ZXING4P();
  try {
    QRCode = zxing4p.generateQRCode("http://"+Server.ip()+":"+port, 200, 200);
    QRCode.save(sketchPath("")+"/qrcode_tmp.gif");
    QRCode = loadImage(sketchPath("")+"/qrcode_tmp.gif");
    generated = true;
  } 
  catch (Exception e) {  
    println("Exception: "+e);
    QRCode = null;
  }

  // websockets
  ws= new WebsocketServer(this, wsPort, "/"+Server.ip()+"dataFlowFromMobile");
  now=millis();

  //cp5

  cp5 = new ControlP5(this);

  oscSettingAddress = cp5.addTextfield("osc_address").setText("127.0.0.1");
  oscSettingAddress.hide();

  oscSettingPort = cp5.addTextfield("osc_port").setText("3334");
  oscSettingPort.hide();

  oscBang = cp5.addBang("ok");
  oscBang.hide();

  oscString = "OSC address and port set to : " + oscSettingAddress.getText() +":"+ oscSettingPort.getText();

  /* start oscP5, listening for incoming messages at port 12000 */
  oscP5 = new OscP5(this, 12000);
  myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));

  //SensorChoice
  d1 = cp5.addDropdownList("sensorChoice")
    .setPosition(20, 240)
    .setWidth(160)
    .hide()
    ;

  d1.getCaptionLabel().set("Mobile Sensor Choice");

  d1.addItem("Orientation", 0) ;
  d1.addItem("Shake", 1) ;
  d1.addItem("Light_Sensor", 2) ;
  d1.addItem("Touch", 3) ;
  d1.setId(0);

  HTMLChoice = 0;

  //orientation : 0 1 2 - Shake 3 - Light 4 - Touch 5 6
  minInputValControl = new  Textfield[7];
  maxInputValControl = new  Textfield[7];
  minOutputValControl = new  Textfield[7];
  maxOutputValControl = new  Textfield[7];
  oscMessage = new  Textfield[7];
  minInputValSet = new Bang[7];
  maxInputValSet = new Bang[7];

  for (int i=0; i < 3; i++) {
    minInputValControl[i] = cp5.addTextfield("min_in "+i).setText("0").setPosition(xPos-10, yPos+(i*125) +40 ).setSize(20, 20).hide();
    maxInputValControl[i] = cp5.addTextfield("max_in "+i).setText("1023").setPosition(xPos-10 + 30, yPos+(i*125)+40).setSize(20, 20).hide();

    minOutputValControl[i] = cp5.addTextfield("min_out "+i).setText("0").setPosition(xPos-10 + 70, yPos+(i*125)+40).setSize(20, 20).hide();
    maxOutputValControl[i] = cp5.addTextfield("max_out "+i).setText("1").setPosition(xPos-10 + 120, yPos+(i*125)+40).setSize(20, 20).hide();

    oscMessage[i] = cp5.addTextfield("osc_message "+i).setText("/surfaces/Quad "+i).setPosition(xPos-10 + 160, yPos+(i*125)+40).setSize(120, 20).hide();

    minInputValSet[i] = cp5.addBang("set min "+i).setPosition(xPos-10, yPos+(i*125)+80).setSize(20, 20).hide();
    maxInputValSet[i] = cp5.addBang("set max "+i).setPosition(xPos-10 +50, yPos+(i*125)+80).setSize(20, 20).hide();
  }

  minInputValControl[3] = cp5.addTextfield("min_in "+3).setText("0").setPosition(xPos-10, yPos +40 ).setSize(20, 20).hide();
  maxInputValControl[3] = cp5.addTextfield("max_in "+3).setText("1023").setPosition(xPos-10 + 30, yPos+40).setSize(20, 20).hide();

  minOutputValControl[3] = cp5.addTextfield("min_out "+3).setText("0").setPosition(xPos-10 + 70, yPos+40).setSize(20, 20).hide();
  maxOutputValControl[3] = cp5.addTextfield("max_out "+3).setText("1").setPosition(xPos-10 + 120, yPos+40).setSize(20, 20).hide();

  oscMessage[3] = cp5.addTextfield("osc_message "+3).setText("/surfaces/Quad "+3).setPosition(xPos-10 + 160, yPos+40).setSize(120, 20).hide();

  minInputValSet[3] = cp5.addBang("set min "+3).setPosition(xPos-10, yPos+80).setSize(20, 20).hide();
  maxInputValSet[3] = cp5.addBang("set max "+3).setPosition(xPos-10 +50, yPos+80).setSize(20, 20).hide();


  minInputValControl[4] = cp5.addTextfield("min_in "+4).setText("0").setPosition(xPos-10, yPos +40 ).setSize(20, 20).hide();
  maxInputValControl[4] = cp5.addTextfield("max_in "+4).setText("1023").setPosition(xPos-10 + 30, yPos+40).setSize(20, 20).hide();

  minOutputValControl[4] = cp5.addTextfield("min_out "+4).setText("0").setPosition(xPos-10 + 70, yPos+40).setSize(20, 20).hide();
  maxOutputValControl[4] = cp5.addTextfield("max_out "+4).setText("1").setPosition(xPos-10 + 120, yPos+40).setSize(20, 20).hide();

  oscMessage[4] = cp5.addTextfield("osc_message "+4).setText("/surfaces/Quad "+4).setPosition(xPos-10 + 160, yPos+40).setSize(120, 20).hide();

  minInputValSet[4] = cp5.addBang("set min "+4).setPosition(xPos-10, yPos+80).setSize(20, 20).hide();
  maxInputValSet[4] = cp5.addBang("set max "+4).setPosition(xPos-10 +50, yPos+80).setSize(20, 20).hide();

  for (int i=5; i < 7; i++) {
    minInputValControl[i] = cp5.addTextfield("min_in "+i).setText("0").setPosition(xPos-10, yPos+((i-5)*125) +40 ).setSize(20, 20).hide();
    maxInputValControl[i] = cp5.addTextfield("max_in "+i).setText("1023").setPosition(xPos-10 + 30, yPos+((i-5)*125)+40).setSize(20, 20).hide();

    minOutputValControl[i] = cp5.addTextfield("min_out "+i).setText("0").setPosition(xPos-10 + 70, yPos+((i-5)*125)+40).setSize(20, 20).hide();
    maxOutputValControl[i] = cp5.addTextfield("max_out "+i).setText("1").setPosition(xPos-10 + 120, yPos+((i-5)*125)+40).setSize(20, 20).hide();

    oscMessage[i] = cp5.addTextfield("osc_message "+i).setText("/surfaces/Quad "+i).setPosition(xPos-10 + 160, yPos+((i-5)*125)+40).setSize(120, 20).hide();

    minInputValSet[i] = cp5.addBang("set min "+i).setPosition(xPos-10, yPos+((i-5)*125)+80).setSize(20, 20).hide();
    maxInputValSet[i] = cp5.addBang("set max "+i).setPosition(xPos-10 +50, yPos+((i-5)*125)+80).setSize(20, 20).hide();
  }
  // print("ARRRRRAY : " + maxInputValSet.length);
  //save load controls
  bangLoad = cp5.addBang("Load_Settings").setPosition(20, height-300).setSize(50, 20).hide();
  bangSave = cp5.addBang("Save_Settings").setPosition(90, height-300).setSize(50, 20).hide();
}


//__________________________________________________________________
public void draw() {
  background(0);
  check_client();
  if (mobileVals != null) {
    // println(HTMLChoice + "\t mobilevals : " + mobileVals.length);
    for (int i=0; i < mobileVals.length; i++) { 
      // println(mobileVals[i]);
    }
  }
  if (generated) {
    // DISPLAY GENERATED IMAGE
    if (QRCode !=null) {
      set(0, 0, QRCode);
    }
    text("Flash this code or \nopen tihs URL on your GSM's browser :\nhttp://" + Server.ip() + ":" + port, 220, 20);
  }
  if (MobileIP !=null) {
    text("Mobile phone connected from :\n"+ MobileIP, 220, 80);
  }

  if ( wscheck ) {
    bangLoad.show();
    bangSave.show();


    oscControls(220, 110);
    myBundle = new OscBundle();
    myMessage = new OscMessage("/");
    myMessage.add("");
    myBundle.add(myMessage);
    myMessage.clear();


    line(220, 230, width-20, 230);
    text("Data from Mobile", 220, 230+20);
    stroke(255);
    /* strokeWeight(2);
     line(x, y-40, width-50, y-40);
     */
    strokeWeight(1);

    if (HTMLChoice == 0) {
      for (int i=0; i < 3; i++) {
        minInputValControl[i].show() ;
        maxInputValControl[i].show() ;
        minOutputValControl[i].show() ;
        maxOutputValControl[i].show() ;
        oscMessage[i].show() ;
        minInputValSet[i].show() ; 
        maxInputValSet[i].show() ;
        if (mobileVals.length == 3) {
          text("Data #"+ PApplet.parseInt(i+1) +" : "+ mobileVals[i], 220, 230+(i*125)+50);
          myMessage.setAddrPattern(oscMessage[i].getText());

          myMessage.add(map(mobileVals[i], PApplet.parseFloat(minInputValControl[i].getText()), PApplet.parseFloat(maxInputValControl[i].getText()), PApplet.parseFloat(minOutputValControl[i].getText()), PApplet.parseFloat(maxOutputValControl[i].getText()) ));
          myBundle.add(myMessage);
          myMessage.clear();
        }
      }

      for (int i=3; i < 7; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }
    } else if (HTMLChoice == 1) {
      for (int i=0; i < 3; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }

      minInputValControl[3].show() ;
      maxInputValControl[3].show() ;
      minOutputValControl[3].show() ;
      maxOutputValControl[3].show() ;
      oscMessage[3].show() ;
      minInputValSet[3].show() ; 
      maxInputValSet[3].show() ;
      if (mobileVals.length == 1) {
        text("Data #"+ 4 +" : "+ mobileVals[0], 220, 230+50);
        myMessage.setAddrPattern(oscMessage[3].getText());

        myMessage.add(map(mobileVals[0], PApplet.parseFloat(minInputValControl[3].getText()), PApplet.parseFloat(maxInputValControl[3].getText()), PApplet.parseFloat(minOutputValControl[3].getText()), PApplet.parseFloat(maxOutputValControl[3].getText()) ));
        myBundle.add(myMessage);
        myMessage.clear();
      }

      for (int i=4; i < 7; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }
    } else if (HTMLChoice == 2) {
      for (int i=0; i < 4; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }

      minInputValControl[4].show() ;
      maxInputValControl[4].show() ;
      minOutputValControl[4].show() ;
      maxOutputValControl[4].show() ;
      oscMessage[4].show() ;
      minInputValSet[4].show() ; 
      maxInputValSet[4].show() ;
      if (mobileVals.length == 1) {
        text("Data #"+ 5 +" : "+ mobileVals[0], 220, 230+50);

        myMessage.setAddrPattern(oscMessage[4].getText());

        myMessage.add(map(mobileVals[0], PApplet.parseFloat(minInputValControl[4].getText()), PApplet.parseFloat(maxInputValControl[4].getText()), PApplet.parseFloat(minOutputValControl[4].getText()), PApplet.parseFloat(maxOutputValControl[4].getText()) ));
        myBundle.add(myMessage);
        myMessage.clear();
      }

      for (int i=5; i < 7; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }
    } else if (HTMLChoice == 3) {
      for (int i=0; i < 5; i++) {
        minInputValControl[i].hide() ;
        maxInputValControl[i].hide() ;
        minOutputValControl[i].hide() ;
        maxOutputValControl[i].hide() ;
        oscMessage[i].hide() ;
        minInputValSet[i].hide() ; 
        maxInputValSet[i].hide() ;
      }

      for (int i=5; i < 7; i++) {
        minInputValControl[i].show() ;
        maxInputValControl[i].show() ;
        minOutputValControl[i].show() ;
        maxOutputValControl[i].show() ;
        oscMessage[i].show() ;
        minInputValSet[i].show() ; 
        maxInputValSet[i].show() ;
        if (mobileVals.length == 2) {
          text("Data #"+ PApplet.parseInt(i+1) +" : "+ mobileVals[i-5], 220, 230+((i-5)*125)+50);
          myMessage.setAddrPattern(oscMessage[i].getText());

          myMessage.add(map(mobileVals[i-5], PApplet.parseFloat(minInputValControl[i].getText()), PApplet.parseFloat(maxInputValControl[i].getText()), PApplet.parseFloat(minOutputValControl[i].getText()), PApplet.parseFloat(maxOutputValControl[i].getText()) ));
          myBundle.add(myMessage);
          myMessage.clear();
        }
      }
    }
    myBundle.setTimetag(myBundle.now() + 10000);

    oscP5.send(myBundle, myRemoteLocation);
  }

  if (client != null) {
    println("server state : " + myServer.active() + "   " + client.ip());
  } else {
  }
  println(mobileVals);
  //fill(255);
  text("2018 - Atelier Soft Machine \nJulien Drochon\nwww.esapyrenees.fr", 20, height-40);
}
String adresseWebsocket;
int portWebsocket;

//__________________________________________________________________
public void make_HTML_file() {
  test = createWriter("index.html");
  test.println("<!DOCTYPE html>");
  test.println("<html><head>");
  test.println("<title>Mobile To MadMapper</title>");
  test.println("<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>");
  test.println("<meta name='Julien Drochon'>");
  test.println("<meta name='apple-mobile-web-app-capable' content='yes'/>");
  test.println("<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />");
  test.println("<meta name='viewport' content='width=device-width' />");
  test.println("<style>#showSensor{height:10%;} @font-face { font-family: 'oo'; src: url(data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAChAAA0AAAAAPBwAAQABAAAAAAAAAAAAAAAAAAAAAAAAAABHUE9TAAABMAAAACAAAAAgRHZMdUdTVUIAAAFQAAAALgAAADAfSCdrT1MvMgAAAYAAAABOAAAAYFspogpjbWFwAAAB0AAAAIoAAADEromxj2dhc3AAAAJcAAAACAAAAAgAAAAQZ2x5ZgAAAmQAAB9AAAAwKLwOmDBoZWFkAAAhpAAAADYAAAA2EgbwaGhoZWEAACHcAAAAHwAAACQL+wIwaG10eAAAIfwAAAIaAAADYOpNHXtsb2NhAAAkGAAAAZ8AAAGyk+iI5m1heHAAACW4AAAAIAAAACABWwEubmFtZQAAJdgAAAEIAAACDCl0Rkpwb3N0AAAm4AAAAV4AAAH/+GE6qAABAAAACgAcAB4AAURGTFQACAAEAAAAAP//AAAAAAAAeNpjYGRgYOBi0GHQY2B2cfMJYRBJSS0zYpADkokMcgwsDEDw/z8DHAAApTwG9gAAeNpjYGEuZtrDwMrAwNTFFMHAwOANoRnjGIwY/RiAgIMBDtgZkIBniJs/wwIGBiVRFql/ixhSWPKZihUYGCaD5Jj0mI4DKQUGFgD6OQsnAAB42mNgYGACYmYgFgGSjGCahWEDkNZgUACyOIAsXoY6hv+MhozBTMeYbjHdURBRkFKQU1BSUFOwUnBRWKMkpCT6/z8DCPAC9SwAqgyCqhRWkFCQAau0RFLJ+P/r/8f/D/2f+L/w7/+/b/6+frD1waYHGx+se7D6wcwHEx5o3jty7xDQLUQCAIvaMVMAAAABAAH//wAPeNqVWgdck9cWv/cGiCwxQBI2hEwIBJIvAxIgSNioiGHKUpkyFBS3VUSrSIer2uHsUCpxVF9dnbaW7l3bX3d9rfV1j/c6X8uXd+/9Qkilb+XHNzjfd88999z/Offccz7gDfAP/oAeATzgA3xBAAjC/wskArHYxFMKIF+s5EvgD2zA7JGRZ0fgdnouR4+M5aJHdE4ne9nJIsg6na87AUCgA7eVo2uYFx/f8aS8EKHUAOXCHcJzp9E1Vgw/Hxt1OMibSSgXLuNJuDdD+FKlBB/nApYGwCJ84kk+wD/yXjAAvGZ0FUSCWMyRzwilfKmJHgaGHgyfHkKJlM+g0YjVeyWHJMOSg5Kdf4m49YG4g3HDcYfibmCfGI4Yhg+s2rcX//at2ncH/u1bhVkDhfMoquDFARVIAUYAZD4+UiyyQqFkRCKxQaHUIIPeaDQZGCH+X4rpQnEMEgL8zMdHGGw06DEFVWQst6u7t/LP8uSxAu+ieputr1C9aGDKBa+4yNii2hx2UC6NV9yeqFJsa0ibPcd3SWNc0pSD3kiorsjPrNOiOXb+4toYBX+fn1hdnguV8qAdKD6G7VPGRsmn7sFzFO78ieePXgH+IAhrQgkYAIBIGOqDuWLxGG8ohV4iRkfEkcb7CL08nvl40KFffX1RSX19CfyUXXcYDrBDUWHhMTHhYVFIVldXXISfGqLCw6Kjw8Kj0CvVs2dXk8NvzIJGH5VKY2PxcQVTamow9VmpNI4QAALRzl/RX9DzQAF0AEiUPnwf0jnp3aSkFyOjE4lFfKleScUIFYmhjMpE/2EQf44fX1SRVtBmrCsMmDYttX56bXPwVN5BxDOIIoMEsIFdmqyTStUpsqZpvvIkc1NW1WLf0HBdTPKslJlZSQZBaHpEqCBKzBq3JMVLNSq5PBkASDAGLlCMUYRdCFwaSICFn0Q48+ArvCtgKgDBwSZG6IOE07yFUgUyROxec3hoCxQcXrMblcHURsES9pMT7JFPpjXA1McBdL6EW27iWsoQX2qQCfRIaWBEwUK4ac/qYRg8ODS8es9l9pWGaZ/AuSdg9BJBI/vqY7jPItgOX8FIFmDRxHwxXymWmvhKk9IkVjJ8uCd97drMpvBlYU3WNavS2yJWhKNzreqEjuqNG+d2qRNaKzduxDzCQSMKQ/UYBwASnGIDwMhkUNjxw8fxHwx64IH9p06RsUc5Z4JnQAe2Z2AkYDBgEJDXnymaGRledEtqbt5ca1i8313A6QQ+MAw+Do8ABN76mrSNBgC8DBxEbybcycunHMRmofMrZy48wDtL6BBKITzA/uMwDOSd/e1WryXEVhMBRHUUpWLcqycex8GoEwkTN+/auWXLzl2b4WByjk2jseUkX3ryySOHn3jicGNbW2NDa0sjZk9HmIAuEf8UYpAIpAJ/GPMgkh4ay0RS8jweTEER6A0QimU16HEnfCmFGR4rXyKUGOC8ApUcDftsX7R02YFFUMxOgZ2b56RZNgz01beN5g71Yx4JGLcK9DFQEWuiLYXkjIWl5k/ll2KdiegwuB7gyg5TgWFrWmfJ6m0+wyhVI1evi4vtVUpkibxh74Fl6GOmJi2v3N87aX1mo2HlmhRjkrTqJmSXKbUJPSup58OntehF4AcCsX4NkBEwQjKXIXwmCdrOV1Qcn3rixMA2+DBbsntgAG76Fkta5WRRFboM4gCAEiEdqMvE3ZK6RBRIkJ59UliSVDBPM7B89vJsNOydrExOTlVLkqYcge+grG1hkdaO7L4t6a22+CRzqkYXLYbHsFzpWBu56ArGmBzrg3ATj2t0YvrEUuTpT7YmKMxaJLCbmvvMvaV7l6+7taePf+i0XpfM6JPVZqRO6lyckLKqt2BR5sWRpy6sn8+OputSUxkttc9gfPoK+w0fulZAiUECvxo7BQF7Gb6LSsbOINMujDWd83s0B31O5dJie3WPnj8uGpbNhE8iD8k8pbSZl86xL03X61YUrpk5Y23hCp3+/hSVKiVVqUwNSddq0y0pKRZUNTctbS6TVio0rCtsMxjaCtcZhKVp+Wp1gkqjUbEOvT45mWGw3AgosKa0WFMRQIFxjjtSujR03cQEcw6OivJZsTnFrajOlZplQzO6LV4Tqhro6HEpau7e7oujma2Z0DKuKkRWJvAZynGtlhgs5Pjs9OnTKMfhYBc6HNiKm5wzoQhZgBIIQD7cjlsFlQLqMwbgwyiDWBJ2Ngxf/OmLL7714osD73/44fsAIPx8BypGao43xKbjjQ9UPPYK0uJDvW+fc+/e6/iEMGK8Aoe/RRihjA/fp3yE+KV/oJ+w7Ue6Vic+FnJiGqQKrB4aDyxbt6btblvhbEWcLOFuZOopDTqNfupubexCNc8kGOIVaklGU/rYGYcDc01mv/F6l2cEZlBIuLrt0z3xWYhilM93aZp0R/oj/5r4ZPkOlnEz4X6B1/bdxsrtZQV1fpKmQmyliF+zrbL7Rl4gEofFpctqTqzdfbn7lVfiTv247i8w5YwqQxOfochIis9U8ozdr93WPDzfOj0rx9KZHxhRuWVGb0uIsD7YJ0qc0mBr3jNn5Uv9x56AN6HVV/aegYHbWMYoLTKa0qTFJoDAFADQG+gxrGk/AOQ45IEMlPoj+D37c9KDkDcKeWerq2s2bECPjeVAHvRifycxigW3WoR94VSs4+jxlV8ikHDeTsnoiJsKJmqWChkkLVnVy56D07uW55rGempqF72j06xaDesbsmpb0aWGquyKQOOMGWzZLIX6IAAQo/mf6FX0PJ01GuK4QWtiqJY5YCPvUxFnQu3pJXV1Jen20DMRp7a07auo2NeGnr91lTZtUV1dd1rqym219y1ceF8tFphKfQ5L7QdCaFzFSSwSehmppAIGnasZ7mV/hP5LjtSwVxcvbi4r++3uuehS9aH25zvmzetgu7B0FoIqzMWf4J44SokQ8xFe+/ZbGMgWwvPIctuG/VvRpUHuXTQFv+tLcUzexusGmsJ+eOWKA7+xd4D9GD/lRvwmHnHs5BFLDRLhVDQxaP9jwjPBxfqyBW2NmXUhb8O20Oqt1Z2HqqoOdqDnBxYrkrvrW7psWWuOZnXkcEN3yXGAkxliCST4YPAZHTjG/uBwwAB0aSwTKtl30CX2GxgMuBbgGrpEIxX89jUHeYXKGuT8FX6L7wIJLy6oY0LxjAvgt6s6+waPlkzHXKIXr9y4pmkG/MTFCx2meierNI92HsLAQRj9yncOx99fggvZ22Emewm3ew6aXC3g89xaa2KweplrV9lex8aNmMQ95VVizAZwo+FxLENCeJWOO2670/Ha4w9TtJ5ji+B5thA9RqL8cTlOcrMhkULSBuI5P+lgP8Y6iHHA0+wsLEIxPOvyqN+hl0l067Zy9yS4DJfCBn57b0PjvU1N9zbic3lTU7m9uakcvVx/uL39SH39kfb2w/UHuxvqFy2qr1/kwuAcOhPBNJYhCKS8MTNiLNccULhuk6XPXt5WVfXLL+jSDR05bZattfXnOT+/iQexVCEEKd5Kt0Tj648YeK44+jqVnJOr+d6GkpwDY29w0pU3rb1hCicaFrPuDu3DcCOVr7vBJWETtW0x1hNPSvDiYh8CXdyl8MidSgeUlfeZK8ruZzd2MKlaXQf0Z39El8wt02d2hbJfwP7kpMRUACDVpQlLraZW5xnLKMa3M4zOA/YisqFBpvTFpSvu4p/10iokCqleY6vIzO4tWn6T7wXvBGmMXKJLya3MwruXvnaVRhYTKRNPE6srcq112p4F0oS42HCpSCBOrswDkCAV93+JW03IeKQGZLp47DFsgWOjyDJIZDRhGQfwOyEE79zkYpSOT7rgr9aMDKtj1paKioFijJH2/OLifHgH2968NS93qBneASD1pK9iDj4ARCIGg/Lx48fP/fQB1sjYVyiUGg+AZN54v+PbAG43iv8wcAl2fz96uXfJ5aMP1a59eG0dtcd3WCXuCiBADuDq4S+cFUuUfGkIjxGbGF4I/Gx3/1Mff/7CjhsuffTN++/DLlj15pvsPvZu2sZl+fgKeXipI92hAz8e+/GpwUHMXfXll/Bt9gqMI+9q8Lsyzj5MNGKVYN/zFUxj/SDDvga/GxoagOe3DuA363HcvYt3dlyjxEThrt272ed5Z4d+v2cIB98QHHDmollcbO4NGQhH2B/ugwGPeC357Vb8lMEcFnIcxAYGzwg28t27ofGRIV7DEH0jGhxGR9BFok+TFKtIyntm5O9Hvh+56zCKHPsUVhGJU5w6dJfzHdoHFhjdNbZbOTxMIzlUCXm8LPIECpUGyPsePd/XtgEgEINnuhMZsP3FEMvmevcw7lBP4y6tE42MiOqy87qt1u48m81kzMszIoNZ1zL2eovOnDdQVb0hb09hdnZhcZa1iFgP5j6IrlLuntEB0ZLgetfxPuWaXSd0OIR12d2YtQl3gQx5G6qrBvJwJ+gq+6nOvKfImlVM+gCQSl+IDP9tbYT37gw5M0WnSDabkxW6KWdCdnbNWV9Y0D8HGVa0y1QFubkFKln7Ck5+4NaKW26x4D9rhUo8WSswcixqslrG+c/EcoeTHQPgS0ScyFPRH1wYHQ6fQTO92Rt4nOT+xUvyOdHt6/KOZSanZHm9CwXhVpMixlJv4HrKXTO7zJRmBJytw3m8QGLHkLBy2TtDNwtiIZyZqEAtLQ6bbdXSsAC0Wqbazi6AB7b7tPfCXVRO9huKjligHkfHH/df/xEqGWvr1t0edHRKusYw/c9R8+asG4pXtMYrMm0L/kRP0BVZXQUhNKrCsnO+XOCCDxzrdVi0+kyHI6wxG+n7e9hHYGqaNSeTfRtj5arOjJtTyX/myWluBgQTzbqSL2LMRp2m0aSR42EH+jvDKBUMo9g/9joixu+8wv4EfqEtRbglGaSrMW/cIUqlzWkch9OJkWHHnp2OljAKJeUzJhZHoqVj254ZH0ctukrWfAkHfuqqbhl2OIaf++u1r7/G4nZcYT9nP5+INq56RBtXx6Lw/9xa/yXSg/hJ+phQjJBbP/CZt2z5SLqWsTjStEyGwyGqzcxeEB7dkon063uJpgwWazr7NrlmmbHGNI0pRotJn+XWu/7P9C78L3rXtOrMLoTPR4b/IWLYtbGkZKPdvqmkZJNda7NptTk5WkSgjI2eO99WYLPl59tsBcSjsD+hQWSY5FGoaP+vR2F38NJaPD0Klhvz70QMmAaigMsZC/6N4DcZR0bMXflLc3P78viFBYyuqEiHmMqy35+FzfMK+u32jUW7C2w5toLp0/NdUdwRrNMAQDalQqJPulhAnxaLNrcEB12/ZJwz57FIs9AVJfDxOFV/9Gw4Frg+A+IKGhjYs37aIb5WHh1jsmTPydAvsPUOBh32MiRiQlbWbPOSdmToqIpXhosjIgKDYvMtqcWJzfUyRaQoOnxqYIzNXFIPIB43gCvQOTLzciGxElcOCwtMhg5XzFzQXVLi6OmJjNu1a37PS9u3bt3+qiSCrmH/RK1IQ33NuLekRsKFD6j1WFijdV7viEWnz0AavGBozf09MJd9LR0DB6oAJJpBXZiDD+47hCHBAMxcdfbpy0+fHYZbqFFC4IUtoBNpJkcMndseb2l9fJujuP1sZzHhD5ezQ0jDLoI72W7izSDhi6qRZlLEcMeS+kcuXLzYW//Io6MHD0Ip9N+/n73KfkNyamMYD2txGz6NYyBu9MjmGx5l73tk4xeY+QisxLMdi8IBJPEhvIw07nghhOxVXoeItX33FTy5bdsWGH7rFvyewamER3lPgGQAAN4X01kVSskcmuhsGvBZSeFGEp/4sZjbq0ODr99M86HwjBQ/32Rjk69fSkb4IfNMP19jOmzoU+izExrXhgUGWBbPUmYbFSqLd4Z/vcKYrZy12BIQGLa2MSHLKDfn+SOiCZlzHXiVl0o8jBhj8NVjxwZ4pzFdjmW7E8uWyvk7KhCWiIlBbkndEuFkliELcbKaDK8Yff3kWTIqnl+KwUDOWD5ZltzPdzHsz2TkxqyErM7iIJeEGXEJmSgDZiXEZbhEDCruzErI1itahIhmM15GTdCBrwT/Io8lXamYSPZBY1y4NDgy2nuDoH1WnF4aKQmOiPHpD26bBUdCQ6ZOlUh7ukJCguiVZFI7nLOgHNtgAcER0meDi4BGESNIiSpJNCojvdDECLV4WlfwDCzgLKPPfv6qmuLONWs7imtW8ff7MhKt2awdksdVd/lWV/tv6u3Z5F9R4dtZEy+zmtOzqLZ/QyXoByDD/Gn2U2nkkr2KScG+mNgZTJPIYQ0LhDrNknJxRnf+kg1TDnglKxTqgKATe34sj9tsT2zI9VlSmjl9vn5di1KrTQ5L1S4h8AZWcDtCaB6tQgBA0thYZ0qcx8Z9kVw2WfdNYpya8/FI8MN/yPVWa6LJkGrNNsnkadk2tdGQkGM1Kh9ISoqTqNUSaEnVZ1uDQ7KzjSnW6cmmbJtgWk62IdlmT1Cp1IkJqgQASc4d3YcukdUSkkIQPrgcuBIf1E5RcPPByIeeOfbsw5GHWnbioPtJONKr773tNnyC4ewotJAxNDvXwWm8VFc2DXvgEIzR5mPkx0tlW8c+g/vwW7FONdKgd4AWZGK9uhZ1JePeSnETSM7X76fIqsFXeI7/E9XKzraVvkd9MsWR0dMzZ1UaLArVyq62Fb5HcaFHHIVppZW9vUlqPAdqeWlJQun87rmzxGKRTB4hqc7SlYbGlCTOmt9Vq1CJxWKpLEJWldmmKUiWxCfhgocaSytGi2AvYrncu2cUYvSMSBJiYxPI8UJCDLmJSUCXExPxBf/runI1sd/RNZyhDgKxNFagq9JEbi0G/WGxFf2nwDj2UE3NobY2eq7ZXFi4uWbujYWFN861L5u6fYoyUqbRyCKVU7ZPXVY6vSU9vWU6erH2vvaF99XV3bew/b5a44yh2tqbZ868ubZ2aEZZw+youHSj0SyJLG0wtubltRpJ9hLWw3PoGW49DfbcX5B5EXmsp1+YQ/r7Q8xJRXW4yJSkpqpDz8RLrOyhrPj4eRXl81vVcrkqUS5LJHlHsBLx4FvAG/iP500Zeh6oqNhfWZlfXn6gqmrlSdeP22s+iJ6DD+EWdH2SGNBzDhbCh9h/3rhhcpXFi2iZ5+PScjLQT45igj1zmVj/wTjjIFViyAvIjPK5tB9Cw/X1w11d9Nxwy4wZNzc23lKCz2d12oV980I7TpSWfmy2WMxYs/cu5DS78N7asbYZN9XW3VRSclNd3dAMOD8n8OT998NjJSZrqpbu51bAe9AXgMdlhOE9bA/6YulSqu9a+CAaJTjzrEFeF7rkLe6ur+/raYhVJ8fFqhJj0eg8e3lTs90+rzY5Wa3RqJOT3dWsFbTiLGRwP4w7GICdx1l4nNa0mjv27u3Yu3LlXtxCBefBbvQC8QAhpIGJMzKP2o/jUfbpAePUgDjv9d4NZUWFGbnwyQUNZVJ5YKA2c1ZWktwci/mEYtQswHxk3Bj4Qqp6d9TDlX10E7yhX1lRosJeVFvmsxkKgiRJirjEaUHR3qt5ZVXohfQUa6CXnyouxWDNDA2KVyQrgwQKY9F1+2K+wYT3xd+jR9v6+gheZuGVfwPSgNCJeIZGme6AZsMx0dyMCPHISCajs5CIA8fPAex3vDT2PYs1ywyVhAvWBOpDj5G4SkI3XwI3fiSob2vBVnFZp07XWQZ7UObYJSiwzDebF1gA0SW4Bt6BOwCPqyi8cwrucDiIzDglS+IRgQuQblXgq/Cj0jLzjvWJQmFRS4LJbDbNjQqcukFH5hLOA2+ji7Q6QG0w/PF+VNfMHvodUNTMhSfR6P8QrUvqdLq6zEx6jktIiCMHGtXY9fo5qal2Rm/XNCWqlGq1UkWsVIetdMq4lYYoSVlCTs9D1Qft9oPQUnUAGypUjpupF6kgoV9pptUXa17MVTK9qcSuiqoJ40/JZ9AAu+V+uJqtxOPYqtpwac8J1T1lZVxeto2Ma+wTq9X24bsb+2mNysnzR6OUa5yLp5Qw9f5zlKIb2fXDcAO7y/p4P3x7EmTRKCm5L8S9OK/HrhfIBoDXQ7GrAgww/o8I9sYi/XGA0PgfMI3Y24ZhJ1So+p/a8qjq7jlz/i3KfYioY6upLnbuxH6uwJmFSAwUBOKRGekvAkyjdQ/eGyCeWhwf2MDzYPef0JeDf3rQT7npo+AJD/rNbvoz4C4P+i43vQMc9aB/5KY/DT4GuwEimOdtwygIojXI8bqCQcrHABRCAQ8N/e1v0JstvZr5EOxA8WzpPciyY+Dg1lWrcBaTvQit7BOYu4L9kVZO4kkdEPNcDTH6MZ3WLOioVK7R9mFpJtOXg/s86Kfc9FHQ6UHf5aZ3ADulk9/3lE8Sx9/5DaWT9K/ETSf8Ywjd+ROmJ1H+HH3UeZXSr2J6FuXP0TucL41rBz1BctKe1ioREEBLgrmMNFUZA588UkNrODk50L+CVHD27SujBZz2u+fC2EEYNfYWqeRsHtzs0gs6SWdP65q9e6jcNPtP5da59PXZn9KXwzAP+ik3fRR85EEn/HUu/uc96Lvc9A78ZDddfxaiaaiW+A65kn6KQUJXMTxw89DioS1LNm/qufGWhTfftOimLb2bb+zecguZ42jM6xf0Mm4rAQkAwIkMAa6ITnzsYmKAGNKgSKaE1LmhPWoNrg1kLkpOq1+gTsG3WeR27L1o6JOUXd4EF0WzvyVn2ZtRTcq6QlzNkMVndafiu8Pkjq3SQmlcd0O+lv0gdlE90SbNoVPtpLm0dgGPdjJ9Ofjcg37KTR8FD3jQd7npHeAOt+0coHwyXHyugN0eNZVAsnKZaIqBub6qMtLprqps3owubVjdmt2ctoGUVSDO2f6CRtE3FHOiyckGJXaX46EzjsunjVdDxGh9PtNg7eyBN/MkUdHRMcrdoaJQlVSugQ4oKGo3KDWzYUtzkbGK6W2OlUjCIpQiuy0gMF4Un5SiZqfAyzBCMytFbQ3TEO3RDCwvC48ul9quDWPxz+jLwese9Cg3fRTcOUFHP7voCDyzZILKut/uABs8uBS76U+Dh+gV071CkQEkkt2GZ8Z2PJ3tmQfVkShX+MccrpfHbsMr1Iud7z1dl5Tme0awdq5tvnAip56N06ahC2yFXRmOfIMuz+cnVujKWsGA0CyzXFK7JF3f6k4q4xxqC5OOE76z0wzpp0jWlKaxyEjYH2lmPB7kc74PHHKPcCbVX6FLr7sm06leL3nQo9z0UTA0QUesi45AB9Erzf14US5PUqoNEmoOpjIe1OWphOqLqVbKmaOO/gxcvnA2Yt3Ujo/IOYbmlq6CaJDggUq3urFxG0wYpGKTkI88NI2kthkDZXMGSwvXlUqzRSJ5V0Fc/J7YGm1Pdm6KLq9Qh4pP17fuKC7cVFWxLjcqKtsksYhk0TGRlqCxn/NtuXm2nNyicc+4iKKojGrhGQ+8zKcjm+PS5v7JdKrNFz3oUW76qIf251P+cziUdk9QWTe1Yy1pEw5kKAzdSXfH/rTiRL8I8cZX2HMK1rAQVp1CdzocX+/d+/6xY/g9AebThAz06wQ5buHSH/WInAqpPzRRtRmVfM4finNxWralSGWfkYczs61FSjvbFDASpdDa/hZwNFKpzYHvzVyB06g6tb10Gb2yFyMvCAtsqsjzofk2LD/NCFItVLu0cxSAyXSsnXc86FFu+ig4NEFHrJveAQYJncvNUT51Lj7PAeDOEV915XCpe3IH79eFs6/14W9B87vSHQ7j4jqcv9UVFOgQUzRQbu8vmMfu433D/lq5O396Tr4tJ6fQ3SeVpY6bk1V0r4Dvf0Wa8Yz9rw6koflKUqP+0Quil7lvkeB4IINTTJ7eApOAJ2x//OYbGMAWxnRlNx2orj7QZO2KxbX7H9jPabm6qRwO428qqjUMqj/c0XGk3qCpHmSrexoaFy9ubFzs8le8z5EBz3YSSJtUYVL+0Xr+vafifc5VnuQ63zP+JUvyrO2S+A4rl6rPXhgvacueqEKxBpy3J/n7iXJUilqdwmXwU9RJGldZ6jRJ5JOEPleXrIKFvCi6K8EmLBYex9//ouOVveXlvQAg+tybV+zKmvyb3ezj+fl6fV6eXhQTIxJHR4t5xTaTKSfHlJaTFx0WFk0O0pcfWgD3YhsTEk40o2hi3PlEHIMz9+MkkihAzq8M6xHLxcH0Nnwx+nlqoL9vym1TA/18U0hUwsAw1ACPjO+9UcPYm/DIrbdyT3jFE094xb9/7nqSjDLAKB0HCCbiC+OFJEJLLswzZG9EKy25dmtu0FpadcZvPuV6k/sulGYKnyrI1Vs38gSZefZs27Q1GInuL0gRCKJIxH3AAbeuPHoxTurxaEEe5ubuN9M83j8i/cONbi4eEogmSfM65eWWyWqakE3j7IYbwRrABy8DMEYyFnZwHvbDT0GQ5xeCHAztqryExDyVKi8xIU8FV+SrVPn4TqnMS8CcokmVHziAFAjAPwAgV8yFSCrAZ0jyQDCW7jCBySP/s3I866PDz2Xc8xDPnaeSe+58mX5dP+r+ZvYHdv1huIHb4JH207Dv+R09j/sBMvd6z6VuTfjimb4l+U6SHMcXjC74V3vog+GnN/efjC61QWgrjT7Zv/l0+IP4Ey3tTOEDT0H41EnhDO2d5KOswb5Sv5AQ39Jlg+RTLV1yqW9IqG9pkpbu28Pg6xOYgq+zBQRTTqf7a1/6Df6/AJJ2vQEAAQAAAAMCj92+JmNfDzz1AAMD6AAAAADVt5HAAAAAANW7GT/9zf2iCa0EVAABAAcAAgAAAAAAAHjaY2BkYGCR+reIIYVz7t+zPyU41wJFUMENAJ7LBzQAeNptkwOMHlEUhc+9b23v/l67tm3btm3bDmvHqR3Vtm3b7vTOTLue5MtVns7J0CeY3zETGo/etAbpajhCeBQSVTwsvAMOPEY6LYOVVminOQi1uBAseA07u+CBV3DQNO0VT0UqdYUvF0cst0MKr0Y6T0ELHopS9Ef2m4bC3AqJFI7i1BNd6BIs3AUWI/oh3O0r8vENePE8lOHPSOTbEi1CgvBD6usoQzFGHchbJb+DMmqR1C8khsu8z784VnptJFaFP+9BCb4KLzcbXLxX9t4gNEZ+Oop2yhsr6RCK8EE4+AAKUHGE8EY4hTLcHRKFPnDSQNlHz9cb56dRrHaP25t3cYtFGb3PE8x1gpO2SUxDIi1HEK+R/UfCT/WHm2jiwaO13/QCkXQCxfAJ8bQPCTwWFkP7JejN1eAUHeO5MirwZgTQUHTlunDRLEQqX9nzMiycD/mUO1y69ko/ZztC6LT0xROaiWQajTAKQwifQX15VwQp6VVECH7J/JixvrAKRSFVV+I0VGRP1NB1zwu1A8rwQnzIirwdQkGK0b4Ij/gp1H8fcsIpsEh06F5kQ/dCPOOrpm554VZYYnehT3aoBkKFyoI31dC+iGbODB9yIrrwUATrXmRDvDA8kyj71HdLQqKbVfZuhRAKFzbAhxejiBqHIniPfEJ+fICdNiOfkN/gAprweTioEfIJhemSdkbFIohewqL/E38BhWegMgAAeNoswQMQ2DAAAMC6URE1s23bx9m2bdu2bdu2bdu27e1f07Rk/+fWSmo9tTN6Qr253kWfqK/TL+hPDd2AhjSSGkWNqkZ3Y5NxxrTMvGYpc7J5xrxnvrI0S1hJrJLWBuu0rdlp7JJ2fbuzvdjeY5+0Hzm6EzppnEJOC2e4s9N55KZwc7lV3RbuMHeBu8097d513wATSJAIpAc1wAiwBTyB8WA+2APOgtvhHfgZOSgXqooGoo3oHvqKs+NyuD0eiOfjnfgcfkRSkWykK1nw+2py21Neea+zN8y760O/pj/Un+ev87cFKFBB3qBC0CVYEWwLbgbfQhAmDjOFNcKO4ZzwEk1BM9F8tAitQOvQFrQLnU4X0/V0Nz1OL9P79DX9ziDLygqy4qwyq89as+5sIrvGHrF3XOOEx+A5eFc+kI/lM/kSvoHvEbFFcpFZ5BdFRQVRWzQTHUUfsUecEFfEA/FGfJdAJpTVZWPZXvaWw+VkeVCekTejWFGLqEc0LzoUnY/uRB8VUUJlV1VUXdVTjVQz1Uq1U/3afwkeCREALBpzfgAAAQAAANgAkAAMAH4ACAABAAIAHgAEAAAAZAAAAAQAAXjadY61lQJAFEXvum9MONm6u7u7S4S7Ox1QASEVUQaF8AJcztjTOR8Yxc0AfYNjQB6quI9p8lXcr0yhigdYpljFg1goVfEQacpVPIyl77+Kp9nsi3NBhCg54vjw4CWJYZ1V1thkqYp2pN0RxqmMTa/hU40oLqFr9VPIIy7NMItPzC31VKjRSVYb7pb8Mg7xEHO8ojm01CHBuVhQmQ0lNIHOAXd8cs2LUGt2qZ5u1U1d/8ZFXIpPXNO3/PrKB0ZYClpSvEolcaAsaeSxLVeHLTblh7ARwIVSuKUG8WFnHfkox5bWHqs9p/SSJCl9nxWtBA7i+MSTwsskhIN6I1I98l+45rECp0tN4XjabMGDgQIAAADAq962baO3bWZryHZpm1qgO0GgXhXWTI1AMBAS0qJVm3YdOnXp1qNXn34DBg0ZNmLUmHETJk2ZNmPWnHkLFi1ZtmLVmnUbNm3ZtmPXnn0HDoUdOXbi1JlzFy5duXbj1p17Dx49efbi1Zt3Hz59+fbj159/EVExcQlJKWkZWTl5BUUlZZUGQfCwFQgAAABw1v+5trNftjtl27bNl3nOrnMzz16qECfekALHEmRIVaRO5bNXUuyJlevWnfRnryWZcORGsXoP7j0q12TOjGZvvZPlvQUfzJq3YtGSZSc+WrdqTYtPrmXbsmHTZ2cuJPvqi29++O6nUr/88dtf/wT4L1CQU8FChQgTIVyvMlEiRYtx7lK/ba3a7Di0q12Hbj0mdeoyJVGDYSMGn71x9expHCx+oT4+TM5B7KV5mQYGjgZQ2gVCO5myuJYW5YM4RkaGpgDW0WvWAAA=); font-style: normal; font-weight: 400;}html{ background-color: black; width:100%; height:100%;overfow:hidden;margin:0;padding:0;}body{font-family:oo;padding:0;margin:0;font-size:1em;width:100%; height:100%;overflow:hidden;} .resultat{ position:fixed; top: 200px;background-color: black; color:#222; width:100%; height:80%; } *{-webkit-touch-callout:none; -webkit-user-select:none; -moz-user-select:none;  -ms-user-select:none; user-select:none;}</style>");
  test.println("</head><body>");
  test.println("<div id='showSensor'></div>");
  test.println("<div class='resultat'></div>");
 // test.println("var video = document.getElementById('video'); var canvas = document.getElementById('canvas');   var context = canvas.getContext('2d'); function trackingColors() {   var tracker = new tracking.ObjectTracker('face');   tracker.setInitialScale(4);   tracker.setStepSize(2);   tracker.setEdgesDensity(0.1);   tracking.track('#video', tracker, { camera: true }); };");  
  test.println("<script>var noBounce=function(){var t={},e={animate:!0},n=[],i={x:0,y:0},a={subtraction:function(t,e){return{x:t.x-e.x,y:t.y-e.y}},length:function(t){return Math.sqrt(t.x*t.x+t.y*t.y)},unit:function(t){var e=a.length(t);t.x/=e,t.y/=e},skalarMult:function(t,e){t.x*=e,t.y*=e}},o=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||function(t){window.setTimeout(t,1e3/60)};function u(t){var e,i;e={x:(i=t.changedTouches[0]).clientX,y:i.clientY,timeStamp:t.timeStamp},n=[e]}function m(t){var e,i,a,u,m,c;t.preventDefault(),e={x:(i=t.changedTouches[0]).clientX,y:i.clientY,timeStamp:t.timeStamp},n.push(e),n.length>1&&(a=n[n.length-1],u=n[n.length-2],m=u.x-a.x,c=u.y-a.y,o(function(){window.scrollBy(m,c)}))}function c(t){var u,m,c,l,s;n.length>2&&e.animate&&(u=n[0],m=n[n.length-1],l=m.timeStamp-u.timeStamp,c=a.subtraction(m,u),s=a.length(c),a.unit(c),a.skalarMult(c,s/l*20),i=c,o(r))}function r(){scrollBy(-i.x,-i.y),a.skalarMult(i,.95),a.length(i)>.2&&o(r)}return t.init=function(t){var n;'boolean'==typeof t.animate&&(e.animate=t.animate),n=t.element,('object'==typeof HTMLElement?n instanceof HTMLElement:n&&'object'==typeof n&&null!==n&&1===n.nodeType&&'string'==typeof n.nodeName)&&(e.element=t.element);var i=e.element||document;i.addEventListener('touchstart',u),i.addEventListener('touchmove',m),i.addEventListener('touchend',c),i.addEventListener('touchcancel',c),i.addEventListener('touchleave',c)},t}();</script>");
  test.println("<script>noBounce.init({animate: true});</script>");
  test.println("<script>!function(t,e){'function'==typeof define&&define.amd?define(function(){return e(t,t.document)}):'undefined'!=typeof module&&module.exports?module.exports=e(t,t.document):t.Shake=e(t,t.document)}('undefined'!=typeof window?window:this,function(t,e){'use strict';function i(i){if(this.hasDeviceMotion='ondevicemotion'in t,this.options={threshold:15,timeout:1e3},'object'==typeof i)for(var s in i)i.hasOwnProperty(s)&&(this.options[s]=i[s]);if(this.lastTime=new Date,this.lastX=null,this.lastY=null,this.lastZ=null,'function'==typeof e.CustomEvent)this.event=new e.CustomEvent('shake',{bubbles:!0,cancelable:!0});else{if('function'!=typeof e.createEvent)return!1;this.event=e.createEvent('Event'),this.event.initEvent('shake',!0,!0)}}return i.prototype.reset=function(){this.lastTime=new Date,this.lastX=null,this.lastY=null,this.lastZ=null},i.prototype.start=function(){this.reset(),this.hasDeviceMotion&&t.addEventListener('devicemotion',this,!1)},i.prototype.stop=function(){this.hasDeviceMotion&&t.removeEventListener('devicemotion',this,!1),this.reset()},i.prototype.devicemotion=function(e){var i,s,n,o=e.accelerationIncludingGravity;if(null===this.lastX&&null===this.lastY&&null===this.lastZ)return this.lastX=o.x,this.lastY=o.y,void(this.lastZ=o.z);i=Math.abs(this.lastX-o.x),s=Math.abs(this.lastY-o.y),n=Math.abs(this.lastZ-o.z),(i>this.options.threshold&&s>this.options.threshold||i>this.options.threshold&&n>this.options.threshold||s>this.options.threshold&&n>this.options.threshold)&&(new Date).getTime()-this.lastTime.getTime()>this.options.timeout&&(t.dispatchEvent(this.event),this.lastTime=new Date),this.lastX=o.x,this.lastY=o.y,this.lastZ=o.z},i.prototype.handleEvent=function(t){if('function'==typeof this[t.type])return this[t.type](t)},i});</script>");
  test.println("<script>var received_msg; var lightflag = false; var luminosity; var hidden = document.getElementById('showSensor'); var  resultat = document.querySelector('.resultat'); var x,y,z;");
  test.println(" if ('WebSocket' in window) { console.log('WebSocket is supported by your Browser!'); var ws = new WebSocket('ws://"+Server.ip()+":"+wsPort+"/"+Server.ip()+"dataFlowFromMobile'); ws.onopen = function() { console.log('Message is sent...'); }; ws.onclose = function() { console.log('Connection is closed...'); }; } else { console.log('WebSocket NOT supported by your Browser!'); }");

  test.println("window.addEventListener('deviceorientation', handleOrientation); function handleOrientation(event) { x = event.beta, y = event.gamma, z = event.alpha;}");

  test.println("var shaked=0; var shakeEvent = new Shake({threshold: 10}); shakeEvent.start(); window.addEventListener('shake', function(){ shaked=1; setTimeout(function(){ if(shaked=1){shaked=0;} }, 1000);}, false);  if(!('ondevicemotion' in window)){alert('Not Supported');}");

  test.println("function update(e){luminosity=e;}if('AmbientLightSensor'in window)try{var sensor=new AmbientLightSensor;sensor.addEventListener('reading',function(e){update(sensor.illuminance)}),sensor.start()}catch(e){alert(e)}if('ondevicelight'in window){function onUpdateDeviceLight(e){update(e.value)}window.addEventListener('devicelight',onUpdateDeviceLight)}");

  test.println("var clientX=0, clientY=0;");

  test.println("window.addEventListener('touchmove', function(e) {   clientX = e.touches[0].clientX;   clientY = e.touches[0].clientY; }, false);");

  test.println("setInterval(data, 25); function data() {");
  test.println("if(parseInt(received_msg)==0)");
  test.println("{ws.send(x+'\t'+y+'\t'+z); resultat.innerHTML  = 'beta : ' + x + '<br />'; resultat.innerHTML += 'gamma: ' + y + '<br />';  resultat.innerHTML += 'alpha: ' + z + '<br />'; }");
  test.println("if(parseInt(received_msg)==1)"); 
  test.println("{ws.send(shaked);resultat.innerHTML=shaked;}");
  test.println("if(parseInt(received_msg)==2)");
  test.println("{ws.send(luminosity); resultat.innerHTML=luminosity+' lux'}");
  test.println("if(parseInt(received_msg)==3)");
  test.println("{ws.send(clientX+'\t'+clientY); resultat.innerHTML='x : ' + clientX + '<br />' + 'y : ' + clientY;}");
test.println("if(parseInt(received_msg)==5)");
test.println("{document.body.style.backgroundColor= 'red'; resultat.style.backgroundColor= 'red';resultat.innerHTML = '<span style=\"color:white;\">Server is Closed<span>';}");
  test.println("ws.onmessage = function (evt) {    received_msg = evt.data;    }");
  test.println(";}</script>");
  
  test.println("</body></html>");
  test.close();
}

//__________________________________________________________________
public void load_HTML_file() {  
  lines = loadStrings("index.html");
  ccount=0;
  for (int i = 0; i < lines.length; i++) {
    ccount += lines[i].length()+1;                                                // add the new line char we send later
  }
  println("HTML file chars ccount: "+ccount);
}

String MobileIP;
boolean sendpage;
Client  client;
//__________________________________________________________________
public void check_client() { 
  sendpage = false;
  boolean sendfavicon = false;

  client = myServer.available();
  if (client != null)
  {
    MobileIP = client.ip();
    if (verbose) println("//___________________________ CLIENT:");
    inString = client.readString();
    if (verbose) println(inString);
    incheck = split(inString, "HTTP/1.1");
    println("client: "+client.ip()+" send: "+inString.length()+" req: "+incheck[0]);
    req = match(incheck[0], "GET / ");                                             // root

    if (req != null) { 
      println(" root ");   
      sendpage = true;
    }
    req = match(incheck[0], "GET /index.html ");                                   // /data/index.html
    if (req != null) { 
      println(" index.html "); 
      sendpage = true;
    }
    // not need <link rel="icon" href="favicon.ico" type="image/x-icon"/> in HTML as all browser ask for it anyway
    req = match(incheck[0], "GET /favicon.ico ");                                   // /data/favicon.ico image file
    if (req != null) { 
      println(" favicon.ico "); 
      sendfavicon = true;
    }


    if (sendpage) {

      if (verbose) println("//___________________________ SERVER: send header");
      client.write("HTTP/1.1 200 OK\r\n");
      if (verbose) println("HTTP/1.1 200 OK/r/n");
      client.write("Content-Length: "+ccount+"\r\n");                                // 124 CHROME ERROR
      if (verbose) println("Content-Length: "+ccount+"/r/n");
      client.write("Content-Type: text/html\r\n\r\n");    
      if (verbose) println("Content-Type: text/html/r/n/r/n");
      if (verbose) println("//___________________________ SERVER: send html file");
      for (int i = 0; i < lines.length; i++) {
        client.write(lines[i]+'\n');                          // format the "browser view page source" with add newline
        if (verbose) println(lines[i]);
      }
      d1.show();
      
      if (verbose) println("//___________________________ STOP");
    } else if (sendfavicon) {                                                                    // send my /data/favicon.ico
      byte b[] = loadBytes("favicon.ico");
      client.write("HTTP/1.1 200 OK\r\n");
      client.write("Content-Length: "+b.length+"\r\n");
      client.write("Content-Type: image/x-icon\r\n\r\n");    
      for (int i = 0; i < b.length; i++) {
        client.write(b[i]);
      }
    } else {                                                                           // ERROR
      client.write("HTTP/1.1 404 not found\r\n");
      client.write("Content-Length: 31\r\n");
      client.write("Content-Type: text/html\r\n\r\n");    
      client.write("<h1>:-/</h1>");
      client.write("ERROR 404 not found");
      println(" bad request ");
    }
  }
}
public void oscControls(int x, int y) {
  oscSettingAddress.show();
  oscSettingPort.show();
  oscBang.show();
  stroke(255);
  strokeWeight(2);
  line(x, y, width-20, y);
  text("OSC Settings", x, y+20);
  oscSettingAddress
    .setPosition(x, y + 30)
    .setSize(100, 20);
  oscSettingPort
    .setPosition(x+120, y + 30)
    .setSize(60, 20);
  oscBang
    .setPosition(x+200, y + 30)
    .setSize(20, 20);
  text(oscString, x, y + 100);
}
//sauvegarde
Bang bangLoad, bangSave;
PrintWriter output;
String saveSettings;

public void fileSaving(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    output = createWriter(selection.getAbsolutePath()+".mobosc");

    output.print(oscSettingAddress.getText()+"\t"); // Write the coordinate to the file
    output.print(oscSettingPort.getText()+"\t");
    for (int i=0; i < 7; i++) {
      output.print(minInputValControl[i].getText()+"\t");
      output.print(maxInputValControl[i].getText()+"\t");

      output.print(minOutputValControl[i].getText()+"\t");
      output.print(maxOutputValControl[i].getText()+"\t");

      output.print(oscMessage[i].getText()+"\t");
    }

    output.flush(); // Writes the remaining data to the file
    output.close(); // Finishes the file
  }
}

public void fileLoading(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {

    BufferedReader reader = createReader(selection.getAbsolutePath());
    String line = null;
    try {
      while ((line = reader.readLine()) != null) {
        settingsLoaded = split(line, TAB);
        println(settingsLoaded.length);
      }
      reader.close();
    } 
    catch (IOException e) {
      e.printStackTrace();
    }
    oscSettingAddress.setText(settingsLoaded[0]); // Write the coordinate to the file
    oscSettingPort.setText(settingsLoaded[1]);
    oscString = "OSC address and port set to : " + oscSettingAddress.getText() +":"+ oscSettingPort.getText();
    myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));

    for (int i=0; i < 7; i++) {
      minInputValControl[i].setText(settingsLoaded[i*5+2]);
      maxInputValControl[i].setText(settingsLoaded[i*5+3]);

      minOutputValControl[i].setText(settingsLoaded[i*5+4]);
      maxOutputValControl[i].setText(settingsLoaded[i*5+5]);

      oscMessage[i].setText(settingsLoaded[i*5+6]);

      flag = true;
    }
  }
}
boolean flag=false;
int HTMLChoice;

public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isController()) {
    if (theEvent.getController().getName()=="sensorChoice") {
      flag = false;

      HTMLChoice = PApplet.parseInt(theEvent.getController().getValue());
      ws.sendMessage(str(HTMLChoice));
      flag = true;
      print("HTML CHOICE : " + HTMLChoice);
    }


    for (int i=0; i < 3; i++) {
      if (theEvent.getController().getName().equals("set min "+i)) {
        minInputValControl[i].setText(str(mobileVals[i]));
      }
    }

    if (theEvent.getController().getName().equals("set min "+3)) {
      minInputValControl[3].setText(str(mobileVals[0]));
    }

    if (theEvent.getController().getName().equals("set min "+4)) {
      minInputValControl[4].setText(str(mobileVals[0]));
    }

    for (int i=5; i < 7; i++) {
      if (theEvent.getController().getName().equals("set min "+i)) {
        minInputValControl[i].setText(str(mobileVals[(i-5)]));
      }
    }

    for (int i=0; i < 3; i++) {
      if (theEvent.getController().getName().equals("set max "+i)) {
        maxInputValControl[i].setText(str(mobileVals[i]));
      }
    }

    if (theEvent.getController().getName().equals("set max "+3)) {
      maxInputValControl[3].setText(str(mobileVals[0]));
    }

    if (theEvent.getController().getName().equals("set max "+4)) {
      maxInputValControl[4].setText(str(mobileVals[0]));
    }

    for (int i=5; i < 7; i++) {
      if (theEvent.getController().getName().equals("set max "+i)) {
        maxInputValControl[i].setText(str(mobileVals[(i-5)]));
      }
    }
    // --------------- OSC

    if (theEvent.getController().getName()=="ok") {
      oscString = "OSC address and port set to : " + oscSettingAddress.getText() +":"+ oscSettingPort.getText();
      myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));
    }

    // --------------- Saving / Loading
    if (theEvent.getController().getName()=="Save_Settings") {
      selectOutput("Select a file to write to:", "fileSaving");
    }
    if (theEvent.getController().getName()=="Load_Settings") {
      selectInput("Select a file to write to:", "fileLoading");
    }
  }
}

public void exit() {
  //put code to run on exit here
  int maintenant = millis();
  ws.sendMessage("5");
  if (millis() - maintenant > 2000){
  super.exit();
  }
}

int xPos = 230;
int yPos = 250;
boolean wscheck;

public void webSocketServerEvent(String msg) {
  wscheck = false;
  mobileVals = PApplet.parseFloat(split(msg, TAB));
  //println("MOBILEVALS : " + mobileVals.length);
  wscheck = true;
}
  public void settings() {  size(520, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Mobile_to_OSC_utility_v1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
