import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import websockets.*; 
import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Arduino_to_WebBrowser_utility extends PApplet {

//Download WEbsockets Library in Processing
//Menu > Sketch > import Library > Add Library > Search websockets > select websockets + click install





ControlP5 cp5;

//Dropdown List
DropdownList d1;

//Websocket
WebsocketServer ws;
int now;

//SErial
Serial myPort;
int[] arduinoVals;
PImage arduino;
String AllDataString;
int arduinoState = 0;
int msgBrowser = 0;

public void setup() {
  

  arduino = loadImage("arduino_board.png");
  ws= new WebsocketServer(this, 5205, "/dataFlowFromArduino");
  now=millis();
  // print(Serial.list());

  cp5 = new ControlP5(this);

  // create a DropdownList, 
  d1 = cp5.addDropdownList("listSerialPort")
    .setPosition(20, 200)
    .setWidth(200)
    ;

  d1.getCaptionLabel().set("Serial Ports");

  for (int i=0; i<Serial.list().length; i++) {
    d1.addItem(Serial.list()[i], i) ;
  }
}
String mouseXstring="", mouseYstring="";
public void draw() {
  smooth();
  background(50);
  // println(msgBrowser);

 
 


  if (millis()>now+15 && arduinoState == 1) {
    for (int i=0; i < arduinoVals.length; i++ ) {
      if (i != arduinoVals.length - 1 ) {
        AllDataString = AllDataString + arduinoVals[i]+ "\t";
      } else {
        AllDataString = AllDataString + arduinoVals[i]+ "\n";
      }
    }
    if(msgBrowser == 1 ){
    ws.sendMessage(AllDataString); 
    }
    // println(AllDataString);
    AllDataString = "";
    now=millis();
  }


  if (arduinoVals != null) {
    for (int i=0; i < arduinoVals.length; i++ ) {
      text("Sensor #"+PApplet.parseInt(i+1)+" data\n" + arduinoVals[i], 20, 250 + (i*35));
    }
  }

  image(arduino, 20, 20, 200, 137);
  if (arduinoState == 0) {
    fill(255, 0, 0);
    stroke(255, 0, 0);
    strokeWeight(2);
    ellipse(width/2 - 7, 170, 7, 7);
    noFill();
    stroke(0, 255, 0);
    ellipse(width/2 + 7, 170, 7, 7);
  } else if (arduinoState == 1) {
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    ellipse(width/2 - 7, 170, 7, 7);
    fill(0, 255, 0);
    stroke(0, 255, 0);
    ellipse(width/2 + 7, 170, 7, 7);
  }

  fill(255);
  textSize(10); 
  text("Atelier Soft Machine\n www.esapyrenees.fr\nJulien Drochon", 20, height -50);
  // println("AllDataString : " + AllDataString);
}


public void webSocketServerEvent(String msg) {
  println("A message from webbrowser : " + msg);
  msgBrowser = PApplet.parseInt(msg);
  println(msgBrowser);
}


public void serialEvent(final Serial s) {
  if ( myPort.available() > 0) {
    arduinoState = 1;
    arduinoVals = PApplet.parseInt(splitTokens(s.readString())); 
    // println(arduinoVals );
  } else {
    arduinoState = 0;
    arduinoVals = null;
  }
  //redraw = true;
}
String portName;
//boolean flag;

public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isController()) {


    if (theEvent.getController().getName()=="listSerialPort") {
      //println( Serial.list()[int(theEvent.getController().getValue())] );
      portName = Serial.list()[PApplet.parseInt(theEvent.getController().getValue())].toString();

      myPort = new Serial(this, portName, 9600);
      myPort.bufferUntil(ENTER);

      new Serial(this, portName, 9600).bufferUntil(ENTER);
     // flag = true;
    }
  }
}
  public void settings() {  size(240, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Arduino_to_WebBrowser_utility" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
