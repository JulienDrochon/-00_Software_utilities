import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import netP5.*; 
import oscP5.*; 
import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Arduino_OSC_Utility_v1 extends PApplet {





ControlP5 cp5;

//Serial
String[] SerialList;
Serial myPort;  // Create object from Serial class
//int val = 0;      // Data received from the serial port

String portName;

PImage logo;

//Dropdown List
DropdownList d1;

//OSC
Textfield oscSettingAddress, oscSettingPort;
Bang oscBang;
OscP5 oscP5;
NetAddress myRemoteLocation;
OscBundle myBundle;
OscMessage myMessage;

//DataSettings
Textfield[] minInputValControl, maxInputValControl, minOutputValControl, maxOutputValControl, oscMessage;
Bang[] minInputValSet, maxInputValSet;
int xPos = 50;
int yPos = 300;
//int numberSensors=2;
String[] settingsLoaded;

//int[] setMinInputVal, setMinInputVal;



//sauvegarde
Bang bangLoad, bangSave;
PrintWriter output;
String saveSettings;
String oscString="";

int[] arduinoVals = new int[5];

public void setup() {
  
  logo = loadImage("arduino_board.png");
  cp5 = new ControlP5(this);

  if (Serial.list().length > 0) {
    myPort =  new Serial(this, Serial.list()[0], 9600);
    myPort.bufferUntil(ENTER);
  }

  // create a DropdownList, 
  d1 = cp5.addDropdownList("listSerialPort")
    .setPosition(25, 170)
    .setWidth(170)
    ;

  d1.getCaptionLabel().set("Serial Ports");

  for (int i=0; i<Serial.list().length; i++) {
    d1.addItem(Serial.list()[i], i) ;
  }
  //OSC controls
  oscSettingAddress = cp5.addTextfield("osc_address").setText("127.0.0.1").setPosition(250, 170).setSize(75, 20);;
  oscSettingAddress.hide();

  oscSettingPort = cp5.addTextfield("osc_port").setText("3334")
    .setPosition(335, 170)
    .setSize(30, 20);
  oscSettingPort.hide();

  oscBang = cp5.addBang("ok")    
  .setPosition(390, 170)
    .setSize(20, 20);
  oscBang.hide();

  oscString = "OSC address and port set to :\n" + oscSettingAddress.getText() +":"+ oscSettingPort.getText();

  /* start oscP5, listening for incoming messages at port 12000 */
  oscP5 = new OscP5(this, 12000);
  myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));

  //save load controls
  bangLoad = cp5.addBang("Load_Settings").setPosition(40, height-40).setSize(50, 20);
  bangSave = cp5.addBang("Save_Settings").setPosition(width-90-50, height-40).setSize(50, 20).hide();
  // output = createWriter("positions.txt");
}

boolean flag;

public void draw() {
  background(128);
  image(logo, 30, -50, 400, 274);
  //text("Serial Ports", 10, 20);

  if (flag) {
    if ( arduinoVals.length > 0) {
      dataSettings(10, yPos);
      oscControls(250, 170);
      bangSave.show();
      text(oscString, 250, 220);

      myBundle = new OscBundle();
      myMessage = new OscMessage("/");
      myMessage.add("");
      myBundle.add(myMessage);
      myMessage.clear();

      for (int i=0; i < arduinoVals.length; i++) {

        myMessage.setAddrPattern(oscMessage[i].getText());

        myMessage.add(map(arduinoVals[i], PApplet.parseFloat(minInputValControl[i].getText()), PApplet.parseFloat(maxInputValControl[i].getText()), PApplet.parseFloat(minOutputValControl[i].getText()), PApplet.parseFloat(maxOutputValControl[i].getText()) ));
        myBundle.add(myMessage);
        myMessage.clear();
        //println(int(map(Integer.parseInt(foo1), float(minInputValControl[i].getText()), float(maxInputValControl[i].getText()), float(minOutputValControl[i].getText()), float(maxOutputValControl[i].getText()) )));
      }

      myBundle.setTimetag(myBundle.now() + 10000);
      /* send the osc bundle, containing 2 osc messages, to a remote location. */
      oscP5.send(myBundle, myRemoteLocation);
    }
  }
  pushMatrix();
  translate(width - 10, height-10);
  rotate(-PI/2);
  text("2018 - Atelier Soft Machine - Julien Drochon - www.esapyrenees.fr", 0, 0);
  popMatrix();
}

public void serialEvent(final Serial s) {
  arduinoVals = PApplet.parseInt(splitTokens(s.readString()));
  redraw = true;
}
public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isController()) {


    if (theEvent.getController().getName()=="listSerialPort") {
      //println( Serial.list()[int(theEvent.getController().getValue())] );
      portName = Serial.list()[PApplet.parseInt(theEvent.getController().getValue())].toString();

      myPort = new Serial(this, portName, 9600);
      myPort.bufferUntil(ENTER);

      //Data Controls
      minInputValControl = new  Textfield[arduinoVals.length];
      maxInputValControl = new  Textfield[arduinoVals.length];
      minOutputValControl = new  Textfield[arduinoVals.length];
      maxOutputValControl = new  Textfield[arduinoVals.length];
      oscMessage =  new  Textfield[arduinoVals.length];
      minInputValSet = new Bang[arduinoVals.length];
      maxInputValSet = new Bang[arduinoVals.length];


      for (int i=0; i < arduinoVals.length; i++) {
        minInputValControl[i] = cp5.addTextfield("min_in "+i).setText("0").setPosition(xPos, yPos+(i*105)+20 ).setSize(40, 20).hide();
        maxInputValControl[i] = cp5.addTextfield("max_in "+i).setText("1023").setPosition(xPos + 50, yPos+(i*105)+20).setSize(40, 20).hide();

        minOutputValControl[i] = cp5.addTextfield("min_out "+i).setText("0").setPosition(xPos + 120, yPos+(i*105)+20).setSize(40, 20).hide();
        maxOutputValControl[i] = cp5.addTextfield("max_out "+i).setText("255").setPosition(xPos + 170, yPos+(i*105)+20).setSize(40, 20).hide();

        oscMessage[i] = cp5.addTextfield("osc_message "+i).setText("/oscmessage/"+i).setPosition(xPos + 220, yPos+(i*105) +20).setSize(120, 20).hide();

        minInputValSet[i] = cp5.addBang("set min "+i).setPosition(xPos, yPos+(i*105)+60).setSize(20, 20).hide();
        maxInputValSet[i] = cp5.addBang("set max "+i).setPosition(xPos +50, yPos+(i*105)+60).setSize(20, 20).hide();
      }

      flag = true;
    }
    if (theEvent.getController().getName()=="Save_Settings") {
      //   println( theEvent.getController().getName() );
      selectOutput("Select a file to write to:", "fileSaving");
    }
    if (theEvent.getController().getName()=="Load_Settings") {
      selectInput("Select a file to write to:", "fileLoading");
    }
    if (theEvent.getController().getName()=="ok") {
      oscString = "OSC address and port set to :\n" + oscSettingAddress.getText() +":"+ oscSettingPort.getText();
      myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));
    }
    // println(theEvent.getController().getName());
    for (int i=0; i < arduinoVals.length; i++) {
      if (theEvent.getController().getName().equals("set min "+i)) {
        minInputValControl[i].setText(str(arduinoVals[i]));
      }
      if (theEvent.getController().getName().equals("set max "+i)) {
        maxInputValControl[i].setText(str(arduinoVals[i]));
      }
    }
  }
}


public void dataSettings(int x, int y) {
  text("Data from Serial Port", x, y-20);
  stroke(255);
  strokeWeight(2);
  line(x, y-40, width-40, y-40);
  strokeWeight(1);
  line(x, y-10, width-40, y-10);


  for (int i=0; i < arduinoVals.length; i++) {
    text("Sensor #"+ PApplet.parseInt(i+1), x, y+(i*105)+10);

    text(arduinoVals[i], x, y+(i*105)+35);

    if (i == arduinoVals.length - 1) {
      strokeWeight(2);
    } else {
      strokeWeight(1);
    }
    line(x, y+(i*105) + 100, width-40, y+(i*105) + 100);

    minInputValControl[i].show();
    maxInputValControl[i].show();

    minOutputValControl[i].show();
    maxOutputValControl[i].show();

    oscMessage[i].show();

    minInputValSet[i].show();
    maxInputValSet[i].show();
  }
}
public void oscControls(int x, int y) {
   oscSettingAddress.show();
  oscSettingPort.show();
   oscBang.show();
}
public void fileSaving(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    // println("User selected " + selection.getAbsolutePath());
    // saveSettings = 
    // output.println("fuque");
    output = createWriter(selection.getAbsolutePath()+".mmosc");

    output.print(oscSettingAddress.getText()+"\t"); // Write the coordinate to the file
    output.print(oscSettingPort.getText()+"\t");
    for (int i=0; i < arduinoVals.length; i++) {
      output.print(minInputValControl[i].getText()+"\t");
      output.print(maxInputValControl[i].getText()+"\t");

      output.print(minOutputValControl[i].getText()+"\t");
      output.print(maxOutputValControl[i].getText()+"\t");

      output.print(oscMessage[i].getText()+"\t");
    }

    output.flush(); // Writes the remaining data to the file
    output.close(); // Finishes the file
  }
}

public void fileLoading(File selection) {
  //print("ulysse");
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {

    BufferedReader reader = createReader(selection.getAbsolutePath());
    String line = null;
    try {
      while ((line = reader.readLine()) != null) {
        /*String[] pieces = split(line, TAB);
         int x = int(pieces[0]);
         int y = int(pieces[1]);
         point(x, y);*/
        settingsLoaded = split(line, TAB);
        println(settingsLoaded.length);
      }
      reader.close();
    } 
    catch (IOException e) {
      e.printStackTrace();
    }
    oscSettingAddress.setText(settingsLoaded[0]); // Write the coordinate to the file
    oscSettingPort.setText(settingsLoaded[1]);
    oscString = "OSC address and port set to : " + oscSettingAddress.getText() +":"+ oscSettingPort.getText();
    myRemoteLocation = new NetAddress(oscSettingAddress.getText(), PApplet.parseInt(oscSettingPort.getText()));

    for (int i=0; i < arduinoVals.length; i++) {
      minInputValControl[i].setText(settingsLoaded[i*5+2]);
      maxInputValControl[i].setText(settingsLoaded[i*5+3]);

      minOutputValControl[i].setText(settingsLoaded[i*5+4]);
      maxOutputValControl[i].setText(settingsLoaded[i*5+5]);

      oscMessage[i].setText(settingsLoaded[i*5+6]);

      flag = true;
    }
  }
}
  public void settings() {  size(450, 770); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Arduino_OSC_Utility_v1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
